#ifndef SSD1306_H
#define SSD1306_H
#define SSD1306_DEFAULT_ADDRESS 						0x78
#define SSD1306_WIDTH 128
#define SSD1306_HEIGHT 64
#define SSD1306_BUFFERSIZE ((SSD1306_WIDTH*SSD1306_HEIGHT)/8)
// SSD1306 Commandset
// ------------------
// Fundamental Commands
#define SSD1306_SET_CONTRAST_CONTROL					0x81
#define SSD1306_DISPLAY_ALL_ON_RESUME					0xA4
#define SSD1306_DISPLAY_ALL_ON							0xA5
#define SSD1306_NORMAL_DISPLAY							0xA6
#define SSD1306_INVERT_DISPLAY							0xA7
#define SSD1306_DISPLAY_OFF								0xAE
#define SSD1306_DISPLAY_ON								0xAF
#define SSD1306_NOP										0xE3
// Scrolling Commands
#define SSD1306_HORIZONTAL_SCROLL_RIGHT					0x26
#define SSD1306_HORIZONTAL_SCROLL_LEFT					0x27
#define SSD1306_HORIZONTAL_SCROLL_VERTICAL_AND_RIGHT	0x29
#define SSD1306_HORIZONTAL_SCROLL_VERTICAL_AND_LEFT		0x2A
#define SSD1306_DEACTIVATE_SCROLL						0x2E
#define SSD1306_ACTIVATE_SCROLL							0x2F
#define SSD1306_SET_VERTICAL_SCROLL_AREA				0xA3
// Addressing Setting Commands
#define SSD1306_SET_LOWER_COLUMN						0x00
#define SSD1306_SET_HIGHER_COLUMN						0x10
#define SSD1306_MEMORY_ADDR_MODE						0x20
#define SSD1306_SET_COLUMN_ADDR							0x21
#define SSD1306_SET_PAGE_ADDR							0x22
// Hardware Configuration Commands
#define SSD1306_SET_START_LINE							0x40
#define SSD1306_SET_SEGMENT_REMAP						0xA0
#define SSD1306_SET_MULTIPLEX_RATIO						0xA8
#define SSD1306_COM_SCAN_DIR_INC						0xC0
#define SSD1306_COM_SCAN_DIR_DEC						0xC8
#define SSD1306_SET_DISPLAY_OFFSET						0xD3
#define SSD1306_SET_COM_PINS							0xDA
#define SSD1306_CHARGE_PUMP								0x8D
// Timing & Driving Scheme Setting Commands
#define SSD1306_SET_DISPLAY_CLOCK_DIV_RATIO				0xD5
#define SSD1306_SET_PRECHARGE_PERIOD					0xD9
#define SSD1306_SET_VCOM_DESELECT						0xDB

#define fontbyte(x) pgm_read_byte(&cfont.font[x])  
#define bitmapbyte(x) pgm_read_byte(&bitmap[x])  
#define bitmapdatatype uint8_t*

typedef enum
{
    LEFT =		0,
    RIGHT  =	1,
    CENTER =	2

} OLEDalign;

typedef enum
{
    OFF =  0,   // OFF pixel of display
    ON  =  1,   // ON pixel of display
    XOR =  2    // INVERSE pixel of display

} OLEDpixelMode;

typedef enum
{
	YES	= 	1,	//need to be updated
	NO	=	0	//not need to be updated

} OLEDupdateFlag;

typedef enum
{
	NORMAL	=	0,	//not inverted
	INVERT	= 	1	//inverted
} OLEDinverted;

typedef enum
{
	SLEEP_ON  = 1,
	SLEEP_OFF = 0	
} OLEDsleepmode;

struct _cache
{
	uint8_t lbnd;	//left changed area boundary
	uint8_t rbnd;	//right changed area boundary
	uint8_t tbnd;	//top changed area boundary
	uint8_t bbnd;	//bottom changed area boundary
	OLEDupdateFlag flag;	//its set to YES than screen need to be updated
	uint8_t buf[SSD1306_BUFFERSIZE];
};

struct _current_font
{
	const uint8_t* font;
	uint8_t x_size;
	uint8_t y_size;
	uint8_t offset;
	uint8_t numchars;
	OLEDinverted inverted;
};

void 	initSSD1306(void);
void	_convert_float(char *buf, double num, int width, unsigned char prec);
void	setBrightness(uint8_t value);
void	update(void);
void	sleepMode(OLEDsleepmode);
void 	clrScr(OLEDinverted mode);
void	chgPixel(uint8_t x, uint8_t y, OLEDpixelMode mode);
void 	invert(OLEDinverted mode);
void 	rInvertStr(uint8_t ry);
void	invertText(OLEDinverted mode);
void	setFont(const uint8_t* font);
void	chr( char c, uint8_t x, uint8_t y);
void	rchr(unsigned char c, uint8_t rx, uint8_t ry);
void	str(char *st, uint8_t OLEDalign, uint8_t y);
void	nmbI(uint8_t num, int x, int y);
void	nmbF(double num, unsigned char dec, int x, int y);
void	rstr (char *st, uint8_t rx, uint8_t ry);
void	image(const unsigned char *imageData);
void	drawLine(int x1, int y1, int x2, int y2);
void	clrLine(int x1, int y1, int x2, int y2);
void	drawCircle(uint8_t x, uint8_t y, uint8_t radius);
void	clrCircle(uint8_t x, uint8_t y, uint8_t radius);

#endif