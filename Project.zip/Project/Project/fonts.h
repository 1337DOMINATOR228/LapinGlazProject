/*--------------------------------------*
 *										*
 * file: fonts.h						*
 * 										*
 * uncomment used fonts includes here	*
 *										*
 *--------------------------------------*/
#ifndef _FONTS_
#define _FONTS_
#include <avr/pgmspace.h>
#define fontdatatype const uint8_t
#include "fonts/TinyFont.h"
#include "fonts/SmallFont.h"
#include "fonts/SmallFont_rus.h"
#include "fonts/MediumNumbers.h"
#include "fonts/BigNumbers.h"
#endif
