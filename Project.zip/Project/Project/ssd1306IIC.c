#include <avr/io.h>
#include <string.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <avr/eeprom.h>
#include <stdlib.h>
#include "i2c_master.h"
#include "ssd1306IIC.h"

struct _cache			bf;
struct _current_font	cfont;


void _convert_float(char *buf, double num, int width, unsigned char prec)
{
	dtostrf(num, width, prec, buf);
}

void sendCommand(uint8_t command) {
    i2c_start(SSD1306_DEFAULT_ADDRESS);
    i2c_write(0x00);
    i2c_write(command);
    i2c_stop();
}

void initSSD1306(void){
	i2c_init();
    // Turn display off
    sendCommand(SSD1306_DISPLAY_OFF);

    sendCommand(SSD1306_SET_DISPLAY_CLOCK_DIV_RATIO);
    sendCommand(0x80);

    sendCommand(SSD1306_SET_MULTIPLEX_RATIO);
    sendCommand(0x3F);
    
    sendCommand(SSD1306_SET_DISPLAY_OFFSET);
    sendCommand(0x00);
    
    sendCommand(SSD1306_SET_START_LINE | 0x0);
    
    // We use internal charge pump
    sendCommand(SSD1306_CHARGE_PUMP);
    sendCommand(0x14);
    
    // Horizontal memory mode
    sendCommand(SSD1306_MEMORY_ADDR_MODE);
    sendCommand(0x00);
    
    sendCommand(SSD1306_SET_SEGMENT_REMAP | 0x1);

    sendCommand(SSD1306_COM_SCAN_DIR_DEC);

    sendCommand(SSD1306_SET_COM_PINS);
    sendCommand(0x12);

    // Max contrast
    sendCommand(SSD1306_SET_CONTRAST_CONTROL);
    sendCommand(0xCF);

    sendCommand(SSD1306_SET_PRECHARGE_PERIOD);
    sendCommand(0xF1);

    sendCommand(SSD1306_SET_VCOM_DESELECT);
    sendCommand(0x40);

    sendCommand(SSD1306_DISPLAY_ALL_ON_RESUME);

    // Non-inverted display
    sendCommand(SSD1306_NORMAL_DISPLAY);

    // Turn display back on
    sendCommand(SSD1306_DISPLAY_ON);

	clrScr(NORMAL);
	update();
	cfont.font=0;
}

void clrScr(OLEDinverted mode){
	if(mode)
		memset(bf.buf, 0xFF, SSD1306_BUFFERSIZE);
	else
		memset(bf.buf, 0x00, SSD1306_BUFFERSIZE);
	bf.lbnd = 0x00;
	bf.rbnd = SSD1306_WIDTH-1;
	bf.tbnd = 0x00;
	bf.bbnd = SSD1306_HEIGHT-1;
	bf.flag = YES;	
}

void update (void){
	if (bf.flag == YES){
		sendCommand(SSD1306_SET_COLUMN_ADDR);
		sendCommand(bf.lbnd);
		sendCommand(bf.rbnd);
		sendCommand(SSD1306_SET_PAGE_ADDR);
		sendCommand(bf.tbnd/8);
		if ((bf.bbnd/8 < 7)&(bf.bbnd % 8)){
			bf.bbnd /= 8;
			bf.bbnd += 1;
		}
		else
			bf.bbnd /= 8;
		sendCommand(bf.bbnd);
		cli();
		i2c_start(SSD1306_DEFAULT_ADDRESS);
		i2c_write(0x40);
		for (uint16_t j = bf.tbnd/8; j <= bf.bbnd; j++){
			for (uint8_t i = bf.lbnd; i <= bf.rbnd; i++){
			
				i2c_write(bf.buf[j*SSD1306_WIDTH+i]);
			}
		}
		i2c_stop();
		sei();
		bf.flag = NO;
	}
}

void sleepMode(OLEDsleepmode mode){
	if(mode)
	sendCommand(SSD1306_DISPLAY_OFF);
	else
	sendCommand(SSD1306_DISPLAY_ON);
}

void setBrightness(uint8_t value){
	sendCommand(SSD1306_SET_CONTRAST_CONTROL);
	sendCommand(value);
}

void invert(OLEDinverted mode)
{
	if (mode)
		sendCommand(SSD1306_INVERT_DISPLAY);
	else
		sendCommand(SSD1306_NORMAL_DISPLAY);
	bf.lbnd = 0x00;
	bf.rbnd = SSD1306_WIDTH-1;
	bf.tbnd = 0x00;
	bf.bbnd = SSD1306_HEIGHT-1;
	bf.flag = YES;
}

void rInvertStr(uint8_t ry){
	uint16_t bfidx;
	uint8_t y;
	uint8_t tmp;
	if ((ry+1)*cfont.y_size <= SSD1306_HEIGHT){
		y = ry*cfont.y_size;
		tmp = cfont.y_size;
		while (y%8){
			for(uint8_t x = 0; x < SSD1306_WIDTH; x++){
				chgPixel (x,y,XOR);
			}
			y++;
			tmp--;
		}
		bfidx = SSD1306_WIDTH*y/8;
		for(uint8_t j=0; j < tmp/8; j++){
			for(uint8_t x = 0; x < SSD1306_WIDTH; x++){
				bf.buf[bfidx] ^=0xFF;
				bfidx++;
			}
			y += 8;
		}
		while(y%cfont.y_size){
			for(uint8_t x = 0; x < SSD1306_WIDTH; x++){
				chgPixel (x,y,XOR);
			}
			y++;
		}
		if (bf.flag == NO){
			bf.lbnd = 0;
			bf.rbnd = SSD1306_WIDTH-1;
			bf.tbnd = ry*cfont.y_size;
			bf.bbnd = (ry+1)*cfont.y_size-1;
			bf.flag = YES;
		}
		else{
			bf.lbnd = 0;
			bf.rbnd = SSD1306_WIDTH-1;
			if (bf.tbnd > ry*cfont.y_size) bf.tbnd = ry*cfont.y_size;
			if (bf.bbnd < ((ry+1)*cfont.y_size-1)) bf.bbnd = (ry+1)*cfont.y_size-1;
		}
	}
}	

void invertText(OLEDinverted mode){
		cfont.inverted=mode;
}

void chgPixel(uint8_t x, uint8_t y, OLEDpixelMode mode){
	uint16_t	by;
	uint8_t		bi;

	if ((x>=0) & (x<SSD1306_WIDTH) & (y>=0) & (y<SSD1306_HEIGHT))
	{
		by=((y/8)*SSD1306_WIDTH)+x;
		bi=y % 8;
		switch (mode){
			case OFF:
				bf.buf[by] &= (~(1<<bi));
			break;
			case XOR:
				bf.buf[by] ^= (1<<bi);
			break;
			case ON:
			default:
				bf.buf[by] |= (1<<bi);
			break;
		}
		if (bf.flag == NO){
			bf.lbnd = bf.rbnd = x;
			bf.tbnd = bf.bbnd = y;
			bf.flag = YES;
		}
		else{
			if (bf.lbnd > x) bf.lbnd = x;
			if (bf.rbnd < x) bf.rbnd = x;
			if (bf.tbnd > y) bf.tbnd = y;
			if (bf.bbnd < y) bf.bbnd = y;
		}
	}
}

void setFont(const uint8_t* font){
	cfont.font=font;
	cfont.x_size=fontbyte(0);
	
	cfont.y_size=fontbyte(1);
	cfont.offset=fontbyte(2);
	cfont.numchars=fontbyte(3);
	cfont.inverted=NORMAL;
}

void chr(char c, uint8_t x, uint8_t y)
{
	if ((cfont.y_size % 8) == 0)
	{
		uint16_t font_idx = ((c - cfont.offset)*(cfont.x_size*(cfont.y_size/8)))+4;
		for (uint8_t rowcnt=0; rowcnt<(cfont.y_size/8); rowcnt++)
		{
			for(uint8_t cnt=0; cnt<cfont.x_size; cnt++)
			{
				for (uint8_t b=0; b<8; b++)
					if ((fontbyte(font_idx+cnt+(rowcnt*cfont.x_size)) & (1<<b))!=0)
						if (cfont.inverted==NORMAL)
							chgPixel(x+cnt, y+(rowcnt*8)+b,ON);
						else
							chgPixel(x+cnt, y+(rowcnt*8)+b,OFF);
					else
						if (cfont.inverted==NORMAL)
							chgPixel(x+cnt, y+(rowcnt*8)+b,OFF);
						else
							chgPixel(x+cnt, y+(rowcnt*8)+b,ON);
			}
		}
	}
	else
	{
		uint16_t font_idx = (c - cfont.offset)*(cfont.x_size*cfont.y_size/8)+4;
		uint8_t cbyte=fontbyte(font_idx);
		uint8_t cbit=7;
		for (int cx=0; cx<cfont.x_size; cx++)
		{
			for (uint8_t cy=0; cy<cfont.y_size; cy++)
			{
				if ((cbyte & (1<<cbit)) != 0)
					if (cfont.inverted==NORMAL)
						chgPixel(x+cx, y+cy,ON);
					else
						chgPixel(x+cx, y+cy,OFF);
				else
					if (cfont.inverted==NORMAL)
						chgPixel(x+cx, y+cy,OFF);
					else
						chgPixel(x+cx, y+cy,ON);
				cbit--;
				if (cbit==0xFF)
				{
					cbit=7;
					font_idx++;
					cbyte=fontbyte(font_idx);
				}
			}
		}
	}
}

void rchr(unsigned char c, uint8_t rx, uint8_t ry){
	chr(c, rx*cfont.x_size, ry*cfont.y_size);
}

void str(char *st, uint8_t align, uint8_t y){
	uint8_t stl;

	stl = strlen(st);
	if (align == RIGHT)
		align = SSD1306_WIDTH-(stl*cfont.x_size)-1;
	if (align == CENTER)
		align = (SSD1306_WIDTH-(stl*cfont.x_size)-1)/2;

	for (uint8_t cnt=0; cnt<stl; cnt++)
			chr(*st++, align + (cnt*(cfont.x_size)), y);
}

void rstr (char *st, uint8_t rx, uint8_t ry){
	uint8_t	stl;
	stl = strlen(st);
	for (uint8_t cnt=0; cnt <stl; cnt++){
		rchr(*st++, rx+cnt, ry);
	}
}

void nmbI(uint8_t num, int x, int y){
	{
		char buf[25];
		char st[27];
		_Bool neg=0;
		int c=0, f=0;
		int length=0;
		char filler=' ';
		if (num==0)
		{
			if (length!=0)
			{
				for (c=0; c<(length-1); c++)
				st[c]=filler;
				st[c]=48;
				st[c+1]=0;
			}
			else
			{
				st[0]=48;
				st[1]=0;
			}
		}
		else
		{
			if (num<0)
			{
				neg=1;
				num=-num;
			}
			
			while (num>0)
			{
				buf[c]=48+(num % 10);
				c++;
				num=(num-(num % 10))/10;
			}
			buf[c]=0;
			
			if (neg)
			{
				st[0]=45;
			}
			
			if (length>(c+neg))
			{
				for (int i=0; i<(length-c-neg); i++)
				{
					st[i+neg]=filler;
					f++;
				}
			}

			for (int i=0; i<c; i++)
			{
				st[i+neg+f]=buf[c-i-1];
			}
			st[c+neg+f]=0;

		}

		str(st,x,y);
	}
}

void nmbF(double num, unsigned char dec, int x, int y)
{
	char st[27];
	_Bool neg = 0;
	char divider = '.';
	char filler=' ';
	int length = 0;
	if (num<0)
	neg = 1;

	_convert_float(st, num, length, dec);

	if (divider != '.')
	{
		for (uint8_t i=0; i<sizeof(st); i++)
		if (st[i]=='.')
		st[i]=divider;
	}

	if (filler != ' ')
	{
		if (neg)
		{
			st[0]='-';
			for (uint8_t i=1; i<sizeof(st); i++)
			if ((st[i]==' ') || (st[i]=='-'))
			st[i]=filler;
		}
		else
		{
			for (uint8_t i=0; i<sizeof(st); i++)
			if (st[i]==' ')
			st[i]=filler;
		}
	}

	str(st,x,y);
}
void image(const unsigned char *imageData){
	memcpy_P( bf.buf, imageData, SSD1306_BUFFERSIZE );
	bf.lbnd = 0x00;
	bf.rbnd = SSD1306_WIDTH-1;
	bf.tbnd = 0x00;
	bf.bbnd = SSD1306_HEIGHT-1;
	bf.flag = YES;
}



void drawHLine(int x, int y, int l)
{
	int by, bi;

	if ((x>=0) && (x<SSD1306_WIDTH) && (y>=0) && (y<SSD1306_HEIGHT))
	{
		for (int cx=0; cx<l; cx++)
		{
			by=((y/8)*128)+x;
			bi=y % 8;

			bf.buf[by+cx] |= (1<<bi);
		}
	}
}

void clrHLine(int x, int y, int l)
{
	int by, bi;

	if ((x>=0) && (x<SSD1306_WIDTH) && (y>=0) && (y<SSD1306_HEIGHT))
	{
		for (int cx=0; cx<l; cx++)
		{
			by=((y/8)*128)+x;
			bi=y % 8;

			bf.buf[by+cx] &= ~(1<<bi);
		}
	}
}

void drawVLine(int x, int y, int l)
{
	if ((x>=0) && (x<SSD1306_WIDTH) && (y>=0) && (y<SSD1306_HEIGHT))
	{
		for (int cy=0; cy<l; cy++)
		{
			chgPixel(x, y+cy,ON);
		}
	}
}

void clrVLine(int x, int y, int l)
{
	if ((x>=0) && (x<SSD1306_WIDTH) && (y>=0) && (y<SSD1306_HEIGHT))
	{
		for (int cy=0; cy<l; cy++)
		{
			chgPixel(x, y+cy,OFF);
		}
	}
}

void drawLine(int x1, int y1, int x2, int y2)
{
	int tmp;
	double delta, tx, ty;
	
	if (((x2-x1)<0))
	{
		tmp=x1;
		x1=x2;
		x2=tmp;
		tmp=y1;
		y1=y2;
		y2=tmp;
	}
	if (((y2-y1)<0))
	{
		tmp=x1;
		x1=x2;
		x2=tmp;
		tmp=y1;
		y1=y2;
		y2=tmp;
	}

	if (y1==y2)
	{
		if (x1>x2)
		{
			tmp=x1;
			x1=x2;
			x2=tmp;
		}
		drawHLine(x1, y1, x2-x1);
	}
	else if (x1==x2)
	{
		if (y1>y2)
		{
			tmp=y1;
			y1=y2;
			y2=tmp;
		}
		drawVLine(x1, y1, y2-y1);
	}
	else if (abs(x2-x1)>abs(y2-y1))
	{
		delta=((double)(y2-y1)/(double)(x2-x1));
		ty=(double)(y1);
		if (x1>x2)
		{
			for (int i=x1; i>=x2; i--)
			{
				chgPixel(i, (int)(ty+0.5),ON);
				ty=ty-delta;
			}
		}
		else
		{
			for (int i=x1; i<=x2; i++)
			{
				chgPixel(i, (int)(ty+0.5),ON);
				ty=ty+delta;
			}
		}
	}
	else
	{
		delta=((float)(x2-x1)/(float)(y2-y1));
		tx=(float)(x1);
		if (y1>y2)
		{
			for (int i=y2+1; i>y1; i--)
			{
				chgPixel((int)(tx+0.5), i,ON);
				tx=tx+delta;
			}
		}
		else
		{
			for (int i=y1; i<y2+1; i++)
			{
				chgPixel((int)(tx+0.5), i,ON);
				tx=tx+delta;
			}
		}
	}

}

void clrLine(int x1, int y1, int x2, int y2)
{
	int tmp;
	double delta, tx, ty;
	
	if (((x2-x1)<0))
	{
		tmp=x1;
		x1=x2;
		x2=tmp;
		tmp=y1;
		y1=y2;
		y2=tmp;
	}
	if (((y2-y1)<0))
	{
		tmp=x1;
		x1=x2;
		x2=tmp;
		tmp=y1;
		y1=y2;
		y2=tmp;
	}

	if (y1==y2)
	{
		if (x1>x2)
		{
			tmp=x1;
			x1=x2;
			x2=tmp;
		}
		clrHLine(x1, y1, x2-x1);
	}
	else if (x1==x2)
	{
		if (y1>y2)
		{
			tmp=y1;
			y1=y2;
			y2=tmp;
		}
		clrVLine(x1, y1, y2-y1);
	}
	else if (abs(x2-x1)>abs(y2-y1))
	{
		delta=((double)(y2-y1)/(double)(x2-x1));
		ty=(double)(y1);
		if (x1>x2)
		{
			for (int i=x1; i>=x2; i--)
			{
				chgPixel(i, (int)(ty+0.5),OFF);
				ty=ty-delta;
			}
		}
		else
		{
			for (int i=x1; i<=x2; i++)
			{
				chgPixel(i, (int)(ty+0.5),OFF);
				ty=ty+delta;
			}
		}
	}
	else
	{
		delta=((float)(x2-x1)/(float)(y2-y1));
		tx=(float)(x1);
		if (y1>y2)
		{
			for (int i=y2+1; i>y1; i--)
			{
				chgPixel((int)(tx+0.5), i,OFF);
				tx=tx+delta;
			}
		}
		else
		{
			for (int i=y1; i<y2+1; i++)
			{
				chgPixel((int)(tx+0.5), i,OFF);
				tx=tx+delta;
			}
		}
	}

}

void drawRect(uint8_t x1, uint8_t y1, uint8_t x2, uint8_t y2)
{
	uint8_t tmp;

	if (x1>x2)
	{
		tmp=x1;
		x1=x2;
		x2=tmp;
	}
	if (y1>y2)
	{
		tmp=y1;
		y1=y2;
		y2=tmp;
	}

	drawHLine(x1, y1, x2-x1);
	drawHLine(x1, y2, x2-x1);
	drawVLine(x1, y1, y2-y1);
	drawVLine(x2, y1, y2-y1+1);
}

void drawCircle(uint8_t x, uint8_t y, uint8_t radius)
{
	int f = 1 - radius;
	int ddF_x = 1;
	int ddF_y = -2 * radius;
	int x1 = 0;
	int y1 = radius;
	
	chgPixel(x, y + radius,ON);
	chgPixel(x, y - radius,ON);
	chgPixel(x + radius, y,ON);
	chgPixel(x - radius, y,ON);
	
	while(x1 < y1)
	{
		if(f >= 0)
		{
			y1--;
			ddF_y += 2;
			f += ddF_y;
		}
		x1++;
		ddF_x += 2;
		f += ddF_x;
		chgPixel(x + x1, y + y1,ON);
		chgPixel(x - x1, y + y1,ON);
		chgPixel(x + x1, y - y1,ON);
		chgPixel(x - x1, y - y1,ON);
		chgPixel(x + y1, y + x1,ON);
		chgPixel(x - y1, y + x1,ON);
		chgPixel(x + y1, y - x1,ON);
		chgPixel(x - y1, y - x1,ON);
	}
}

void clrCircle(uint8_t x, uint8_t y, uint8_t radius)
{
	int f = 1 - radius;
	int ddF_x = 1;
	int ddF_y = -2 * radius;
	int x1 = 0;
	int y1 = radius;
	
	chgPixel(x, y + radius,OFF);
	chgPixel(x, y - radius,OFF);
	chgPixel(x + radius, y,OFF);
	chgPixel(x - radius, y,OFF);
	
	while(x1 < y1)
	{
		if(f >= 0)
		{
			y1--;
			ddF_y += 2;
			f += ddF_y;
		}
		x1++;
		ddF_x += 2;
		f += ddF_x;
		chgPixel(x + x1, y + y1,OFF);
		chgPixel(x - x1, y + y1,OFF);
		chgPixel(x + x1, y - y1,OFF);
		chgPixel(x - x1, y - y1,OFF);
		chgPixel(x + y1, y + x1,OFF);
		chgPixel(x - y1, y + x1,OFF);
		chgPixel(x + y1, y - x1,OFF);
		chgPixel(x - y1, y - x1,OFF);
	}
}
